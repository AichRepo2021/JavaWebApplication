package com.shopping.CartApplication;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.shopping.bo.Affiliate;
import com.shopping.bo.Customer;
import com.shopping.bo.Employee;
import com.shopping.serviceImpl.DiscountFactory;

class DiscountFactoryTest {

	@Test
	void testBillamountCustomer() {
		DiscountFactory discountFactory = new DiscountFactory();

		Customer c = new Customer();
		c.setId(1001);
		c.setAmount(1000.00);
		c.setProductName("Dress");
		c.setName("sushil");
		c.setUserType("Customer");
		c.setResisterDate("1-26-2018 07:15:50");
		
		double expectedAmt=  discountFactory.billamount(c);
		assertEquals(951.00, expectedAmt); 
		assertEquals(950.00, expectedAmt); 
	}
	
	@Test
	void testBillamountOtherCustome_before2year_resister() {
		DiscountFactory discountFactory = new DiscountFactory();
		Customer c = new Customer();
		c.setId(1001);
		c.setAmount(1000.00);
		c.setProductName("Dress");
		c.setName("sushil");
		c.setUserType("Customer");
		c.setResisterDate("14-09-2021 07:15:50");
		
		double expectedAmt=  discountFactory.billamount(c);
		assertEquals(951.00, expectedAmt); 
	}
	
	@Test
	void testBillamountEmployee() {
		DiscountFactory discountFactory = new DiscountFactory();

		Employee emp= new Employee();
		emp.setId(1001);
		emp.setAmount(1000.00);
		emp.setProductName("Dress");
		emp.setName("sushil");
		emp.setUserType("Customer");
		emp.setResisterDate("1-26-2021 07:15:50");
		
		double expectedAmt=  discountFactory.billamount(emp);
		assertEquals(951.00, expectedAmt); 
	}
	@Test
	void testBillamountAffiliate() {
		DiscountFactory discountFactory = new DiscountFactory();

		Affiliate  af= new Affiliate();
		af.setId(1001);
		af.setAmount(1000.00);
		af.setProductName("Dress");
		af.setName("sushil");
		af.setUserType("Customer");
		af.setResisterDate("1-26-2021 07:15:50");
		
		double expectedAmt=  discountFactory.billamount(af);
		assertEquals(700.00, expectedAmt); 
	}
	
	

}
