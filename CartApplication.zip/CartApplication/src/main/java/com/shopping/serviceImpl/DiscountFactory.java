package com.shopping.serviceImpl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.shopping.bo.Affiliate;
import com.shopping.bo.Customer;
import com.shopping.bo.Employee;
import com.shopping.bo.User;
import com.shopping.service.Discount;

public class DiscountFactory implements Discount {
	SimpleDateFormat obj = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");

	@Override
	public double getDiscount(User user) {
		double amount = 0.00;
		if (user instanceof Employee) {
			String productName = ((Employee) user).getProductName();
			amount = ((Employee) user).getAmount();
			if (!productName.equals("groceries")) {

				double quotient = (amount * 30) / 100;
				amount = amount - quotient;
				System.out.println("Total Bill::" + amount);
				System.out.println("Employee 30%  Discount Apply" + quotient);
				System.out.println("After discount::" + amount);
			} else {
				if (amount > 100) {
					amount = extracted(amount);

				}
			}

		} else if (user instanceof Customer) {
			try {
				String productName = ((Customer) user).getProductName();
				Date todayDate = obj.parse(((Customer) user).getResisterDate());
				amount = ((Customer) user).getAmount();
				if (!productName.equals("groceries")) {

					Date date1 = obj.parse("12-12-2018 02:11:20");

					// Date date2 = obj.parse("1-26-2020 07:15:50");
					long time_difference = todayDate.getTime() - date1.getTime();
					long hours_difference = (time_difference / (1000 * 60 * 60)) % 24;
					if (hours_difference > 2) {
						double quotient = (amount * 5) / 100;
						amount = amount - quotient;
						System.out.println("Total Bill::" + amount);
						System.out.println("Customer 5 %  Discount Apply" + quotient);
						System.out.println("After discount::" + amount);
					}

				} else {
					amount = extracted(amount);
				}
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(amount);
			return amount;
		} else if (user instanceof Affiliate) {

			String productName = ((Affiliate) user).getProductName();
			amount = ((Affiliate) user).getAmount();
			if (!productName.equals("groceries")) {
				double quotient = (amount * 10) / 100;
				amount = amount - quotient;
				System.out.println("Total Bill::" + amount);
				System.out.println("Affiliate 10 %  Discount Apply" + quotient);
				System.out.println("After discount::" + amount);

			} else {

				amount = extracted(amount);
			}

		}
		return amount;

	}

	private double extracted(double amount) {
		double quotient = amount / 100;

		amount = amount - (quotient * 5);
		return amount;
	}

	@Override
	public double billamount(User user) {
		String UserType = user.getUserType();
		double amount = 0.00;
		if (UserType.equals("Customer")) {
			amount = getDiscount(user);

		} else if (UserType.equals("Employee")) {
			amount = getDiscount(user);

		} else if (UserType.equals("Affiliate")) {
			amount = getDiscount(user);
		} else {
			amount = getDiscount(user);
		}
		return amount;
	}

}
