package com.shopping.CartApplication;

import com.shopping.bo.Customer;
import com.shopping.service.Discount;
import com.shopping.serviceImpl.DiscountFactory;

public class TestCase {
	public static void main(String[] args) {
		DiscountFactory discountFactory=new DiscountFactory();
		
		Customer c=new Customer();
		c.setId(1001);
		c.setAmount(1000.00);
		c.setProductName("Dress");
		c.setName("sushil");
		c.setUserType("Customer");
		c.setResisterDate("1-26-2021 07:15:50");
		discountFactory.billamount(c);
	}

}
