package com.shopping.service;

import com.shopping.bo.User;

public interface Discount {
	public double getDiscount(User user);
	//public double billamount(String UserType,double amount,String productName);
	public double billamount(User user);

}
